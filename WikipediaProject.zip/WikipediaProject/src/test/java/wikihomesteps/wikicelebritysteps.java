package wikihomesteps;

import gherkin.lexer.Th;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import wikihomepages.wikihomepages;
import wikihomepages.wikiLanguageHomePage;

public class wikicelebritysteps {
    WebDriver driver = null;
    wikihomepages wikihome;
    wikiLanguageHomePage languageHomePage;

    @When("user enters <celebrity_name> in search field")
    public void user_enters_celebrity_name_in_search_field(String celebrity_name) throws Throwable {
        wikihome = new wikihomepages(driver);

        wikihome.enterLanguage(celebrity_name);
        Thread.sleep(3000);
        System.out.println("User enters celebrity name:" +celebrity_name);

    }

    @Then("user navigates to <celebrity_name> home")
    public void user_navigates_to_celebrity_name_home(String celebrity_name) throws Throwable{
        languageHomePage = new wikiLanguageHomePage(driver);
        languageHomePage.CelebrityHeader(celebrity_name);
        Thread.sleep(3000);
        driver.close();
        driver.quit();
    }

    @Then("log birthdates and spouse details")
    public void log_birthdates_spouse_details(String celebrity_name) throws Throwable{
        languageHomePage = new wikiLanguageHomePage(driver);
        languageHomePage.CelebrityDOB(celebrity_name);
        languageHomePage.CelebritySpouse(celebrity_name);
    }
}
